# Validação técnica — Catálogo 02B.2

Validações realizadas antes do empacotamento:

```text
5 arquivos TypeScript/TSX: transpilação sintática aprovada
functions/lib/createEventOrder.js: node --check aprovado
Firestore Rules: estrutura e balanceamento revisados
Cálculo de oferta: teste com 2 kits aprovado
```

Teste de cálculo:

```text
Produtos elegíveis: 10 × ¥300
Quantidade por kit: 5
Kits aplicados: 2
Preço promocional por kit: ¥1.000
Subtotal elegível: ¥3.000
Desconto: ¥1.000
Total elegível: ¥2.000
```

O build completo do Next.js precisa ser confirmado no projeto local, pois o
pacote de revisão não inclui `node_modules`.
