# Catálogo 02B.2 — ofertas e kits dentro dos eventos

## Resultado

As ofertas cadastradas em:

```text
sellers/{sellerId}/offers/{offerId}
```

podem ser selecionadas ao criar ou editar um evento.

O evento guarda snapshots independentes em:

```text
sellers/{sellerId}/events/{eventId}/offers/{offerId}
```

Os produtos participantes entram automaticamente em:

```text
sellers/{sellerId}/events/{eventId}/items/{productId}
```

## Comportamento

- um evento pode publicar várias ofertas;
- selecionar uma oferta inclui automaticamente seus produtos elegíveis;
- produtos exigidos por uma oferta não podem ser removidos enquanto ela estiver selecionada;
- outros produtos podem ser adicionados normalmente;
- o cliente escolhe no máximo uma oferta por pedido nesta etapa;
- itens fora da oferta continuam no preço normal;
- vários kits completos da mesma oferta são calculados;
- o pedido grava subtotal, desconto, total e snapshot da oferta;
- itens `made_to_order` continuam compráveis sem estoque imediato;
- o detalhe do pedido mostra a oferta aplicada.

## Instalação

Na raiz de `yamada-landing`:

```bash
git add -A
git commit -m "checkpoint antes das ofertas em eventos 02B2"

unzip -o yamada-catalog-02b2-event-offers.zip -d .
rm -rf .next
npm run build
```

## Firestore Rules

Depois que o build passar:

```bash
firebase use yamada-apps
firebase deploy --only firestore:rules
```

A única nova permissão é para snapshots em:

```text
sellers/{sellerId}/events/{eventId}/offers/{offerId}
```

Leitura pública; escrita somente pelo dono do seller ou administrador.

## Cloud Function

O pacote atualiza:

```text
functions/_src/createEventOrder.ts
functions/lib/createEventOrder.js
```

A função passa a aceitar `selectedOfferId`, recalcular a oferta, preservar
snapshots e ignorar estoque imediato para itens sob encomenda.

Caso `createEventOrder` já esteja publicada:

```bash
firebase deploy --only functions:createEventOrder
```

O fluxo público atual também calcula e valida novamente os snapshots do evento
em uma transação do Firestore, portanto o teste da interface não depende do
deploy da Function.

## Teste funcional

1. Crie uma oferta com pelo menos dois produtos participantes.
2. Abra `/seller/events/new`.
3. Selecione a oferta.
4. Confirme que os produtos participantes ficam selecionados automaticamente.
5. Crie o evento.
6. Confira no Firestore:

```text
events/{eventId}.offerIds
events/{eventId}/offers/{offerId}
events/{eventId}/items/{productId}
```

7. Abra `/event/{sellerId}/{eventId}`.
8. Selecione a oferta no carrossel.
9. Adicione produtos participantes suficientes para formar o kit.
10. Adicione também um produto que não participa da promoção.
11. Confirme que o desconto atinge apenas os produtos elegíveis.
12. Finalize o pedido.
13. Confira no pedido:

```text
subtotal
discount
totalAmount
offersApplied
items
```

14. Abra o pedido no painel e confira a identificação da oferta.
15. Edite o evento pela aba Configurações e teste adicionar/remover ofertas.

## Arquivos alterados

```text
app/seller/events/new/page.tsx
app/seller/events/[eventId]/EventPanelClient.tsx
app/event/[...id]/EventClient.tsx
app/seller/events/[eventId]/orders/[orderId]/OrderDetailClient.tsx
firestore.rules
functions/_src/createEventOrder.ts
functions/lib/createEventOrder.js
```
