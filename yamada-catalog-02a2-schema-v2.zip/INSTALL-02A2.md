# Catálogo 02A.2 — produtos, categorias e estoque no schema V2

## O que muda

Produtos passam a gravar os campos canônicos:

```text
schemaVersion: 2
categoryId
content.pt / content.en / content.ja
priceMinor
costPriceMinor
unitsPerSale
inventory.tracked
inventory.quantity
inventory.lowStockThreshold
```

Categorias novas passam a gravar:

```text
schemaVersion: 2
names.pt / names.en / names.ja
status
sortOrder
```

## Compatibilidade temporária

Para não quebrar eventos, relatórios e pedidos durante a migração, o modal ainda
mantém os espelhos antigos:

```text
name
description
category
sellPrice
costPrice
quantity
stockQty
lowStockThreshold
```

Esses espelhos serão removidos somente depois que todas as telas e o backend
estiverem lendo exclusivamente o schema V2.

A loja pública já passa a priorizar:

```text
content
priceMinor
inventory
```

com fallback para os campos antigos.

## Modal

O mesmo `ProductModal` e `ProductForm` continuam sendo usados para criação e
edição. Foram adicionados:

- nome, descrição curta, detalhes, ingredientes e alérgenos em PT/EN/JA;
- controle de estoque opcional;
- limite de estoque baixo configurável;
- preço salvo na unidade mínima da moeda;
- unidades por venda;
- categoria com `categoryId` estável.

## Instalação

Na raiz de `yamada-landing`:

```bash
git add -A
git commit -m "checkpoint antes do schema v2 de produtos 02A2"

unzip -o yamada-catalog-02a2-schema-v2.zip -d .
```

Encerre qualquer `npm run dev` aberto antes de limpar o cache:

```bash
rm -rf .next
npm run build
```

## Testes

1. Crie uma categoria e confirme `names`, `status` e `sortOrder`.
2. Crie um produto preenchendo ao menos um idioma.
3. Confira `priceMinor` de acordo com JPY/BRL/USD.
4. Confirme `inventory` e `unitsPerSale`.
5. Edite o produto no mesmo modal.
6. Abra `/store/{sellerId}` e confirme nome, descrição, preço e estoque.
7. Confirme que eventos existentes ainda exibem o produto pelos espelhos de compatibilidade.

## Firestore Rules

Este pacote não altera as Rules. As regras atuais já permitem que o dono do
seller grave esses campos dentro de sua própria coleção de produtos e categorias.
