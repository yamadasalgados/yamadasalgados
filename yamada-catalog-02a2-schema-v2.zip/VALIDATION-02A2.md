# Validação técnica

Foram verificados sintaticamente com TypeScript:

```text
app/lib/product-schema.ts
app/seller/products/product-types.ts
app/seller/products/ProductForm.tsx
app/seller/products/ProductModal.tsx
app/seller/products/page.tsx
app/store/[sellerId]/StoreClient.tsx
```

O build completo deve ser confirmado no projeto local, onde estão todas as
dependências e a árvore completa do Next.js.
