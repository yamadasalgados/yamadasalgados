# Yamada Print Service

Serviço local gratuito para imprimir automaticamente os pedidos da Yamada em uma impressora térmica de 80 mm instalada no macOS.

## Arquitetura

1. Um pedido é criado na loja permanente ou em um evento.
2. A API da Vercel coloca um trabalho na fila privada do seller.
3. Este programa, executado no Mac, busca o trabalho.
4. Gera duas vias em PDF de 80 mm: produção e cliente.
5. Envia os PDFs para a fila CUPS do macOS.
6. Confirma a impressão e impede duplicações no mesmo Mac.

Nenhuma chave do Firebase Admin é instalada no computador. O programa usa apenas uma chave específica da estação de impressão, que pode ser substituída pelo seller.

## Antes da impressora chegar: modo preview

1. No painel do seller, abra **Configurações > Impressão automática**.
2. Clique em **Gerar chave de conexão**.
3. Copie `print-service/.env.example` para `.env`:

```bash
cd print-service
cp .env.example .env
```

4. Preencha `YAMADA_SELLER_ID` e `YAMADA_PRINT_TOKEN`.
5. Mantenha:

```env
PRINT_MODE=preview
```

6. Teste:

```bash
npm run doctor
npm start
```

7. No painel, clique em **Enviar impressão de teste**. Os PDFs aparecerão em `print-service/output/`.

## Depois que a MUNBYN chegar

1. Instale o driver macOS indicado pela MUNBYN.
2. Conecte a impressora por LAN ou USB e adicione-a em **Ajustes do Sistema > Impressoras e Scanners**.
3. Descubra o nome da fila:

```bash
lpstat -p
```

Exemplo:

```text
printer MUNBYN_P072 is idle
```

4. Atualize `.env`:

```env
PRINT_MODE=cups
PRINTER_NAME=MUNBYN_P072
```

5. Confira:

```bash
npm run doctor
npm run once
```

6. Envie um teste pelo painel.

## Iniciar automaticamente com o Mac

```bash
./scripts/install-macos.sh
```

O serviço continuará rodando em segundo plano. Se o Mac ou a impressora estiverem desligados, os trabalhos permanecem na fila e serão tentados novamente quando o serviço voltar.

## LAN ou USB?

Para uma impressora fixa, LAN é recomendada: a impressora pode ficar perto da produção e o Mac só precisa estar na mesma rede. USB também funciona quando a impressora fica ao lado do Mac.

## Duas vias

A configuração do painel permite:

- produção + cliente;
- somente produção;
- somente cliente.

Em modo CUPS, cada via é enviada como um trabalho separado, permitindo que o cortador automático separe as vias de acordo com o driver da impressora.

## Diagnóstico

```bash
npm run doctor
```

Logs do serviço automático:

```bash
tail -f logs/output.log
tail -f logs/error.log
```

## Segurança

Se a chave da estação vazar ou o Mac for substituído, abra o painel e clique em **Substituir chave de conexão**. A chave anterior deixa de funcionar imediatamente.
