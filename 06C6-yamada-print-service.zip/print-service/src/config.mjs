import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(HERE, "..");

function readEnvFile() {
  const file = path.join(ROOT, ".env");
  if (!fs.existsSync(file)) return {};
  return Object.fromEntries(
    fs.readFileSync(file, "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#") && line.includes("="))
      .map((line) => {
        const index = line.indexOf("=");
        const key = line.slice(0, index).trim();
        let value = line.slice(index + 1).trim();
        if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        return [key, value];
      }),
  );
}

const fileEnv = readEnvFile();
const env = (name, fallback = "") => process.env[name] ?? fileEnv[name] ?? fallback;

export const config = {
  baseUrl: env("YAMADA_BASE_URL").replace(/\/+$/, ""),
  sellerId: env("YAMADA_SELLER_ID"),
  token: env("YAMADA_PRINT_TOKEN"),
  stationName: env("YAMADA_STATION_NAME", "Yamada Print Service"),
  printMode: env("PRINT_MODE", "preview").toLowerCase(),
  printerName: env("PRINTER_NAME"),
  chromePath: env("CHROME_PATH", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
  lpOptions: env("LP_OPTIONS"),
  pollIntervalMs: Math.max(1000, Number(env("POLL_INTERVAL_MS", "3000")) || 3000),
  heartbeatIntervalMs: Math.max(10000, Number(env("HEARTBEAT_INTERVAL_MS", "30000")) || 30000),
};

export function assertConfig() {
  const missing = [];
  if (!config.baseUrl) missing.push("YAMADA_BASE_URL");
  if (!config.sellerId) missing.push("YAMADA_SELLER_ID");
  if (!config.token) missing.push("YAMADA_PRINT_TOKEN");
  if (config.printMode === "cups" && !config.printerName) missing.push("PRINTER_NAME");
  if (missing.length) throw new Error(`Configuração ausente: ${missing.join(", ")}`);
  if (!['preview', 'cups'].includes(config.printMode)) {
    throw new Error("PRINT_MODE deve ser preview ou cups.");
  }
}
