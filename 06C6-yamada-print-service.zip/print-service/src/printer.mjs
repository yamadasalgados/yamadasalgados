import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

import { config, ROOT } from "./config.mjs";
import { receiptDocument } from "./receipt.mjs";

const execFileAsync = promisify(execFile);

function splitOptions(value) {
  return value.match(/(?:[^\s"]+|"[^"]*")+/g)?.map((part) => part.replace(/^"|"$/g, "")) ?? [];
}

async function renderPdf(html, outputPath) {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "yamada-print-"));
  const htmlPath = path.join(tempDir, "receipt.html");
  await fs.writeFile(htmlPath, html, "utf8");

  await execFileAsync(config.chromePath, [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--no-pdf-header-footer",
    `--print-to-pdf=${outputPath}`,
    `file://${htmlPath}`,
  ], { timeout: 45_000, maxBuffer: 2_000_000 });

  await fs.rm(tempDir, { recursive: true, force: true });
}

async function sendToCups(pdfPath) {
  const args = ["-d", config.printerName, ...splitOptions(config.lpOptions), pdfPath];
  const { stdout } = await execFileAsync("lp", args, { timeout: 30_000 });
  return stdout.trim();
}

export async function printJob(job) {
  const copies = job.copies === "production"
    ? ["production"]
    : job.copies === "customer"
      ? ["customer"]
      : ["production", "customer"];

  const outputDir = path.join(ROOT, "output");
  await fs.mkdir(outputDir, { recursive: true });
  const outputFiles = [];

  for (const copyType of copies) {
    const document = receiptDocument(job, copyType);
    const filename = `${new Date().toISOString().replaceAll(":", "-")}_${job.jobId}_${copyType}.pdf`;
    const outputPath = path.join(outputDir, filename);
    await renderPdf(document.html, outputPath);
    outputFiles.push(outputPath);

    if (config.printMode === "cups") {
      await sendToCups(outputPath);
    }
  }

  return outputFiles;
}
