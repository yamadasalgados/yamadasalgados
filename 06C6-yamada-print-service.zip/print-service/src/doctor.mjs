import { execFile } from "node:child_process";
import fs from "node:fs";
import { promisify } from "node:util";
import { api } from "./api.mjs";
import { assertConfig, config } from "./config.mjs";

const execFileAsync = promisify(execFile);

async function main() {
  assertConfig();
  console.log("✓ Configuração básica preenchida");
  if (!fs.existsSync(config.chromePath)) throw new Error(`Google Chrome não encontrado em: ${config.chromePath}`);
  console.log("✓ Google Chrome encontrado");

  if (config.printMode === "cups") {
    const { stdout } = await execFileAsync("lpstat", ["-p"]);
    if (!stdout.includes(`printer ${config.printerName} `)) {
      throw new Error(`Fila CUPS não encontrada: ${config.printerName}\n${stdout}`);
    }
    console.log(`✓ Impressora CUPS encontrada: ${config.printerName}`);
  } else {
    console.log("✓ Modo preview: PDFs serão gerados em output/");
  }

  await api.heartbeat();
  console.log("✓ API da Vercel aceitou a estação");
  console.log("Tudo pronto.");
}

main().catch((error) => {
  console.error(`✗ ${error instanceof Error ? error.message : error}`);
  process.exitCode = 1;
});
