# Catálogo 02A — cadastro e edição de produtos via modal

Este pacote refatora somente a experiência da página:

```text
/seller/products
```

## Resultado

O formulário incorporado à página foi removido. Agora o fluxo é:

```text
Adicionar Produto
→ ProductModal
→ ProductForm
→ salvar
→ confirmação dentro do modal
→ atualização imediata da lista
→ fechamento automático
→ toast discreto
```

A edição usa exatamente os mesmos componentes:

```text
Editar
→ ProductModal com o produto selecionado
→ ProductForm preenchido
→ atualizar
```

## Comportamentos implementados

- modal centralizado com aproximadamente 900 px no desktop;
- modal praticamente em tela cheia no celular;
- header fixo;
- footer fixo;
- somente o conteúdo central possui rolagem;
- foco automático no nome do produto;
- ESC fecha quando não há salvamento em andamento;
- clique no fundo tenta fechar o modal;
- alterações não salvas exigem confirmação;
- o modal não fecha durante gravação, criação de categoria ou upload;
- botão mostra `Salvando...` ou `Enviando imagens...`;
- validações aparecem próximas ao campo correspondente;
- erros inesperados aparecem no topo do modal;
- confirmação de sucesso aparece dentro do modal;
- lista é atualizada de forma otimista e depois reconciliada pelo `onSnapshot`;
- toast é exibido após a criação ou edição;
- criação de categoria permanece dentro do formulário;
- imagens existentes e novas continuam funcionando na edição.

## O que não foi alterado

Este pacote não modifica:

```text
firestore.rules
storage.rules
firebase.json
estrutura dos documentos
caminho das coleções
lógica de upload
payload de criação e edição
```

O upload continua usando exatamente:

```text
sellers/{uid}/products/{productIdLike}/...
```

Os produtos continuam em:

```text
sellers/{sellerId}/products/{productId}
```

E as categorias em:

```text
sellers/{sellerId}/categories/{categoryId}
```

## Campos preservados

O formulário atual encontrado no código contém:

```text
name
category
costPrice
sellPrice
quantity
stockQty
status
imageUrl
extraImageUrls
```

`description` e `eventGroup` não estavam presentes no formulário atual recebido.
Eles não foram introduzidos neste pacote porque isso alteraria a estrutura dos
documentos e contrariaria o requisito de refatoração exclusivamente visual.
Esses campos poderão entrar na fase de evolução do schema do Catálogo 02A.

## Instalação

Na raiz de `yamada-landing`, registre o estado atual:

```bash
git add -A
git commit -m "checkpoint antes do modal de produtos 02A"
```

Depois instale:

```bash
unzip -o yamada-catalog-02a-product-modal.zip -d .
rm -rf .next
npm run build
```

## Arquivos alterados ou adicionados

```text
app/seller/products/page.tsx
app/seller/products/ProductModal.tsx
app/seller/products/ProductForm.tsx
app/seller/products/product-types.ts
app/seller/products/product-catalog-utils.ts
```

## Teste funcional

Depois do build:

```bash
npm run dev
```

Teste em `/seller/products`:

1. clicar em `Adicionar Produto`;
2. verificar foco no campo nome;
3. tentar salvar campos inválidos;
4. selecionar imagens;
5. criar uma categoria dentro do modal;
6. salvar um produto;
7. confirmar atualização da lista e toast;
8. editar o mesmo produto;
9. pressionar ESC sem alterações;
10. alterar um campo e pressionar ESC;
11. confirmar que aparece aviso de descarte;
12. testar em largura de celular.
