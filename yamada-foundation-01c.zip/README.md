# Fundação 01C — mensal, anual, Lifetime e schemaVersion 2

Este pacote substitui o modelo duplicado de plano/assinatura por uma separação
clara entre identidade, perfil comercial e acesso.

## Modelo criado

### `users/{uid}`

Somente identidade e permissão:

```text
schemaVersion
role
sellerId
email
displayName
photoURL
uiLanguage
accountStatus
createdAt / updatedAt
createdBy / updatedBy
```

O documento `users` não guarda plano, valor, limites, país da loja ou
solicitações de assinatura.

### `sellers/{sellerId}`

Fonte comercial principal:

```text
schemaVersion
ownerUid
storeName
storefrontLanguage
regional
onboarding
accountStatus
access
limitsOverride
regionId / regionName
whatsapp / messengerId
pickupLink / pickupNote
createdAt / updatedAt
createdBy / updatedBy
```

### `sellers/{sellerId}/planRequests/{requestId}`

Cada solicitação fica em um documento separado, preservando o histórico:

```text
planId
billingInterval
requestType
status
country
currency
amountMinor
limitsSnapshot
createdAt / createdBy
reviewedAt / reviewedBy / reviewNote
```

## Modos de acesso

```text
subscription + monthly
subscription + annual
lifetime + billingInterval null
```

Lifetime não é um status. Ele é um modo de acesso que não vence
automaticamente, mas ainda pode ser suspenso ou revogado pelo administrador.

## Preços

O anual custa dez mensalidades e concede doze meses de acesso.

| Plano | JP mensal/anual | BR mensal/anual | US mensal/anual |
|---|---:|---:|---:|
| Starter | ¥2.980 / ¥29.800 | R$69 / R$690 | US$19 / US$190 |
| Pro | ¥5.980 / ¥59.800 | R$139 / R$1.390 | US$39 / US$390 |
| Business | ¥9.980 / ¥99.800 | R$229 / R$2.290 | US$69 / US$690 |

## Segurança aplicada

- administrador depende de `users/{uid}.role == "admin"`;
- a lista fixa de e-mails administrativos foi removida;
- sellers não podem alterar o próprio plano, Lifetime, limites ou status;
- Lifetime só pode ser concedido/revogado pelo administrador;
- solicitações são validadas por país, moeda, intervalo, preço e limites;
- pedidos públicos só são aceitos com conta e acesso ativos;
- `/events` e `/products` na raiz ficam permanentemente bloqueados;
- o novo catálogo administrativo usa `sellers/{sellerId}/products`;
- a limpeza automática antiga foi desativada para não apagar Lifetime/anual.

## 1. Criar checkpoint

Na raiz de `yamada-landing`:

```bash
git add -A
git commit -m "checkpoint antes da fundacao de acesso 01C"
```

## 2. Instalar

Coloque o ZIP na raiz e execute:

```bash
unzip -o yamada-foundation-01c.zip -d .
```

O pacote substitui somente os arquivos listados em `manifest.json`.

## 3. Auditar referências antigas

```bash
node scripts/audit-legacy-root-paths.cjs
```

As regras já impedem que `/events` ou `/products` da raiz sejam lidos ou
recriados. O auditor apenas informa se algum fallback antigo ainda aparece em
arquivos não enviados no pacote.

## 4. Validar o projeto

```bash
rm -rf .next
npm run build
```

Não publique nem faça push antes do build concluir.

## 5. Publicar regras e índices

```bash
firebase use yamada-apps
firebase deploy --only firestore:rules,firestore:indexes
```

O deploy das regras é obrigatório; o build do Next.js não altera permissões do
Firestore.

## 6. Transformar sua conta em Admin + Business Lifetime

O script usa Firebase Admin e sobrescreve somente os documentos raiz da conta.
Subcoleções não são apagadas.

Com a chave na pasta Downloads:

```bash
node scripts/bootstrap-admin-lifetime.cjs \
  --email will@will.com \
  --store-name "Admin" \
  --country JP \
  --language pt \
  --plan business \
  --key "$HOME/Downloads/NOME-DA-CHAVE.json"
```

Use o e-mail real da conta no Firebase Authentication. A chave privada nunca
deve entrar no GitHub.

O resultado esperado é:

```text
users/{uid}.role = admin
users/{uid}.accountStatus = active
sellers/{sellerId}.access.planId = business
sellers/{sellerId}.access.mode = lifetime
sellers/{sellerId}.access.status = active
```

Não é necessário zerar o Firestore novamente.

## 7. Testar

Reinicie:

```bash
rm -rf .next
npm run dev
```

Depois faça logout e login novamente.

Rotas principais:

```text
/admin/plans     solicitações, mensal/anual, Lifetime e suspensão
/admin/products  catálogos pertencentes a cada seller
/seller/rent     escolha mensal ou anual
```

## Fluxo de uma nova conta seller

```text
cadastro
→ users/{uid} mínimo
→ sellers/{sellerId} mínimo
→ onboarding
→ solicitação em planRequests
→ aprovação pelo admin
→ acesso mensal ou anual ativo
```

## Validação realizada neste pacote

- 31 arquivos TypeScript/TSX do pacote passaram pela análise sintática do TypeScript;
- scripts Node passaram por `node --check`;
- `firebase.json` e `firestore.indexes.json` são JSON válidos;
- delimitadores das Firestore Rules foram verificados;
- referências diretas a `/events` e `/products` não existem nos arquivos
  alterados do pacote.

O build completo precisa ser confirmado no projeto local, onde todas as
dependências e todos os arquivos estão disponíveis.
