# Checklist funcional 01C

## Firestore depois do bootstrap

### users/{uid}

- [ ] `schemaVersion: 2`
- [ ] `role: "admin"`
- [ ] `sellerId` correto
- [ ] `uiLanguage` correto
- [ ] `accountStatus: "active"`
- [ ] sem `plan`, `subscriptionStatus`, `maxEvents` ou `requestedPlan`

### sellers/{sellerId}

- [ ] `schemaVersion: 2`
- [ ] `ownerUid` correto
- [ ] `regional.operatingCountry: "JP"`
- [ ] `regional.currency: "JPY"`
- [ ] `regional.locale: "ja-JP"`
- [ ] `regional.timeZone: "Asia/Tokyo"`
- [ ] `onboarding.complete: true`
- [ ] `access.planId: "business"`
- [ ] `access.mode: "lifetime"`
- [ ] `access.billingInterval: null`
- [ ] `access.status: "active"`

## Aplicação

- [ ] login redireciona o admin para `/admin`
- [ ] `/admin/plans` abre sem erro
- [ ] `/seller` pode ser aberto pela conta admin Lifetime
- [ ] `/seller/rent` mostra mensal e anual
- [ ] `/admin/products` não consulta `/products` na raiz
- [ ] `/admin/events` usa eventos dentro de sellers
- [ ] nenhum documento reaparece em `/events` ou `/products`
